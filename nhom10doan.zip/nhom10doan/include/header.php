<div>
    <div class="container">
        <div class="row">
            <div style="display: flex; flex-direction: column; align-items: center; width: 100%;
            justify-content: center;">
                <div>
                    <h5> KÝ TÚC XÁ - ĐẠI HỌC CÔNG THƯƠNG THÀNH PHỐ HỒ CHÍ MINH</h5>
                </div>
                <div>
                    <h7> 140 Lê Trọng Tấn - Tây Thạnh - Tân Phú - TP.HCM</h7>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <nav class="menu">
                    <ul>
                        <li><a class="ad" href="index.php?action=login">Đăng nhập</a></li>
                        <li><a href="../document.pdf">Document</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
</div>